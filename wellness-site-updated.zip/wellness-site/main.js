
/*
 * This is the main JavaScript loader that includes advice data and logic.
 */
const script1 = document.createElement('script');
script1.src = 'adviceData.js';
document.head.appendChild(script1);

const script2 = document.createElement('script');
script2.src = 'logic.js';
document.head.appendChild(script2);
